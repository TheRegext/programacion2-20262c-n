#ifndef ARCHIVOLIBROS_H_INCLUDED
#define ARCHIVOLIBROS_H_INCLUDED

class ArchivoLibro{
    char _nombreArchivo[20];
public:
    ArchivoLibro(const char *nombreArchivo="libros.dat");
    bool agregarRegistroLibro();
    bool mostrarRegistroLibro();
    int buscarRegistroLibro(int isbn);
    bool borradoLogicoRegistro();
    Libro leerRegistro(int pos);
    bool sobreEscribirRegistro(Libro reg,int pos);
    bool modificarCantidad();
    int cantidadRegistros(int activos=0);
};
#endif // ARCHIVOLIBROS_H_INCLUDED
