#pragma once
#include "fecha.h"

using namespace std;

class Socio
{

///  DNI, el nombre, el apellido, un n�mero de tel�fono, un email y la fecha de nacimiento
private:
    int _dni;
    string _apellido;
    int _numTelefono;
    string _nombre;
    string _email;
    Fecha _fechaNacimiento;
    ///int diaNacimiento, mesNacimiento, anioNacimiento;
    int _id;


public:
    void setDni(int dni);
    int getDni();
    ///
    void setDiaNacimiento(int d);
    ///
    void setApellido(string apellido);
    string getApellido();
    void setNumTelefono(int numTelefono);
    int getNumTelefono();
    void setNombre(string nombre);
    string getNombre();
    void setEmail(string email);
    string getEmail();
    void setFechaNacimiento(Fecha fechaNacimiento);
    Fecha getFechaNacimiento();
    void setId(int id);
    int getId();

    void cargar();
    void mostrar();

    int getMesNacimiento();
};
